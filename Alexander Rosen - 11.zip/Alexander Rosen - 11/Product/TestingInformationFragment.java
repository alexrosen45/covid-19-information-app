package com.covid19.covid_19_app;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class TestingInformationFragment extends Fragment {

    String Data_Url;
    View v;
    Dialog testing_dialog;
    private Button testing_button;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_testing_information, container, false);

        Data_Url = "https://disease.sh/v3/covid-19/all";
        new TestingInformationFragment.Asynchttptask().execute(Data_Url);

        testing_button = (Button) v.findViewById(R.id.testing_button);
        testing_dialog = new Dialog(getContext());

        testing_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button testing_information_dialog;

                testing_dialog.setContentView(R.layout.testing_dialog);
                testing_information_dialog = (Button) testing_dialog.findViewById(R.id.testing_information_dialog);

                testing_information_dialog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://myhealth.alberta.ca/Journey/COVID-19/Pages/Assessment.aspx"));
                        startActivity(browserIntent);
                        testing_dialog.dismiss();
                    }
                });
                testing_dialog.show();
            }
        });
        return v;
    }


    public class Asynchttptask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String result = "";
            String response = "";
            URL url;
            HttpURLConnection urlConnection = null;

            // urls can be null so try and catch will stop the app from crashing
            try {
                url = new URL (urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                int responseCode = urlConnection.getResponseCode();

                // stops data from being parsed if it is html and not json
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    response = streamToString(urlConnection.getErrorStream());
                } else {
                    response = streamToString(urlConnection.getInputStream());
                }
                // if there is an error with connecting uncomment the comments below
                // if it still does not work try change "POST" to "GET"
                //urlConnection.connect();
                //urlConnection.setRequestMethod("POST");
                //response = streamToString(urlConnection.getInputStream());
                parseResult(response);
                return result;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    String streamToString(InputStream stream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
        String data;
        String result = "";

        // while there is data being streamed convert that data to a string
        while ((data = bufferedReader.readLine()) != null) {
            result+=data;
        }
        if (stream != null) {
            stream.close();
        }
        return result;
    }

    @SuppressLint("SetTextI18n")
    private void parseResult(String result) {
        JSONObject response = null;

        TextView total_tests = (TextView) v.findViewById(R.id.total_tests);

        // result can be null so try and catch will stop the app from crashing
        try {
            response = new JSONObject(result);

            String tests = response.optString("tests");

            total_tests.setText(tests);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
