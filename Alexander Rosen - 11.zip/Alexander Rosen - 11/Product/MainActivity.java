package com.covid19.covid_19_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.covid19.covid_19_app.GlobalNews.GlobalNewsFragment;
import com.covid19.covid_19_app.LocalNews.LocalNewsFragment;
import com.covid19.covid_19_app.VaccineInformation.VaccineInformationFragment;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout = findViewById(R.id.nav_view);
        Toolbar toolbar = findViewById(R.id.toolbar);
        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view);

        navigationView.setNavigationItemSelectedListener(this);

        // setting fragment_statistics as the home page
        getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new StatisticsFragment());


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_draw_open, R.string.navigation_draw_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.white));
        toggle.syncState();

        // makes sure a fragment is always filled
        if (savedInstanceState==null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new StatisticsFragment()).commit();
            navigationView.setCheckedItem(R.id.statistics);
        }
    }

    @Override
    // returns true for items selected by the user
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.statistics:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new StatisticsFragment()).commit();
                break;
            case R.id.local_news:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new LocalNewsFragment()).commit();
                break;
            case R.id.global_news:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new GlobalNewsFragment()).commit();
                break;
            case R.id.sanitation:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new SanitationFragment()).commit();
                break;
            case R.id.testing_information:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new TestingInformationFragment()).commit();
                break;
            case R.id.vaccine_information:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new VaccineInformationFragment()).commit();
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    // closes nav bar if left open for too long of if there is an error
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }


    // buttons to websites with more information
    public void open_more_statistics(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://covid19.who.int/"));
        startActivity(browserIntent);
    }
    public void open_symptoms_information(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.cdc.gov/coronavirus/2019-ncov/symptoms-testing/symptoms.html"));
        startActivity(browserIntent);
    }
}