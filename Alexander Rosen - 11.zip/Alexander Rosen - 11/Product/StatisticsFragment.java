package com.covid19.covid_19_app;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.covid19.covid_19_app.GlobalNews.GlobalNewsData;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsDateData;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsImageData;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsSourceData;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class StatisticsFragment extends Fragment {

    String global_data_url, local_data_url;

    Parameters global_parameters, local_parameters;
    Asynchttptask global_http_task, local_http_task;

    View v;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_statistics, container, false);

        global_data_url = "https://disease.sh/v3/covid-19/all";
        local_data_url = "https://services1.arcgis.com/0MSEUqKaxRlEPj5g/arcgis/rest/services/ncov_cases2_v1/FeatureServer/2/query?where=1%3D1&outFields=Country_Region,Last_Update,Confirmed,Deaths,Recovered,Active,People_Tested,People_Hospitalized,Mortality_Rate&returnGeometry=false&outSR=4326&f=json";
        global_parameters = new Parameters("global data", global_data_url);
        local_parameters = new Parameters("local data", local_data_url);

        global_http_task = new StatisticsFragment.Asynchttptask();
        local_http_task = new StatisticsFragment.Asynchttptask();
        global_http_task.execute(global_parameters);
        local_http_task.execute(local_parameters);

        return v;
    }

    private static class Parameters {
        String task;
        String url;

        Parameters(String task, String url) {
            this.task = task;
            this.url = url;
        }
    }

    public class Asynchttptask extends AsyncTask<Parameters, Void, String> {

        @Override
        protected String doInBackground(Parameters... parameters) {
            String result = "";
            String response = "";
            String task = "";
            URL url;
            HttpURLConnection urlConnection = null;

            // urls can be null so try and catch will stop the app from crashing
            try {
                task = parameters[0].task;

                url = new URL (parameters[0].url);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                int responseCode = urlConnection.getResponseCode();

                // stops data from being parsed if it is html and not json
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    response = streamToString(urlConnection.getErrorStream());
                } else {
                    response = streamToString(urlConnection.getInputStream());
                }
                // if there is an error with connecting uncomment the comments below
                // if it still does not work try change "POST" to "GET"
                //urlConnection.connect();
                //urlConnection.setRequestMethod("POST");
                //response = streamToString(urlConnection.getInputStream());

                if (task=="global data") {
                    parseGlobalResult(response);
                }
                if (task=="local data") {
                    parseLocalResult(response);
                }

                return result;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    String streamToString(InputStream stream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
        String data;
        String result = "";

        // while there is data being streamed convert that data to a string
        while ((data = bufferedReader.readLine()) != null) {
            result+=data;
        }
        if (stream != null) {
            stream.close();
        }
        return result;
    }

    @SuppressLint("SetTextI18n")
    private void parseGlobalResult(String result) {
        JSONObject response = null;

        TextView total_cases = (TextView) v.findViewById(R.id.total_cases);
        TextView total_cases_today = (TextView) v.findViewById(R.id.total_cases_today);
        TextView recovered_cases = (TextView) v.findViewById(R.id.recovered_cases);
        TextView active_cases = (TextView) v.findViewById(R.id.active_cases);
        TextView critical_cases = (TextView) v.findViewById(R.id.critical_cases);
        TextView death_toll = (TextView) v.findViewById(R.id.death_toll);
        TextView affected_countries = (TextView) v.findViewById(R.id.affected_countries);

        // result can be null so try and catch will stop the app from crashing
        try {
            response = new JSONObject(result);

            String total = response.optString("cases");
            String today = response.optString("todayCases");
            String recovered = response.optString("recovered");
            String active = response.optString("active");
            String critical = response.optString("critical");
            String deaths = response.optString("deaths");
            String countries = response.optString("affectedCountries");

            total_cases.setText(total);
            total_cases_today.setText(today);
            recovered_cases.setText(recovered);
            active_cases.setText(active);
            critical_cases.setText(critical);
            death_toll.setText(deaths);
            affected_countries.setText(countries);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    @SuppressLint("SetTextI18n")
    private void parseLocalResult(String result) {
        JSONObject response = null;
        String country;

        TextView local_data_title = (TextView) v.findViewById(R.id.local_data_title);
        TextView local_total_cases = (TextView) v.findViewById(R.id.local_total_cases);
        TextView local_recovered_cases = (TextView) v.findViewById(R.id.local_recovered_cases);
        TextView local_active_cases = (TextView) v.findViewById(R.id.local_active_cases);
        TextView local_death_toll = (TextView) v.findViewById(R.id.local_death_toll);
        TextView local_mortality_rate = (TextView) v.findViewById(R.id.local_mortality_rate);
        TextView data_last_updated = (TextView) v.findViewById(R.id.data_last_updated);

        // result can be null so try and catch will stop the app from crashing
        try {
            response = new JSONObject(result);

            country = getCountry();

            if (country.equals("CA")||country.equals("ca")) {
                country = "canada";
            }

            JSONArray features = response.getJSONArray("features");
            for (int i = 0; i<features.length(); i++) {
                JSONObject get_data = features.optJSONObject(i);
                JSONObject attributes = get_data.optJSONObject("attributes");
                String countries = attributes.optString("Country_Region");

                if (country.equals(countries.toLowerCase())) {
                    String title = countries+" - Local Data";
                    String total = attributes.optString("Confirmed");
                    String recovered = attributes.optString("Recovered");
                    String active = attributes.optString("Active");
                    String deaths = attributes.optString("Deaths");
                    long last_updated = attributes.optLong("Last_Update");

                    // rounding mortality rate double to 6 significant figures
                    double mortality = attributes.optDouble("Mortality_Rate");
                    String mortality_rate = String.valueOf(Math.round(mortality*100000)/100000.0);

                    // JSON UNIX time (ms) to ctime Date conversion
                    java.util.Date time=new java.util.Date((long)last_updated);

                    local_data_title.setText(title);
                    local_total_cases.setText(total);
                    local_recovered_cases.setText(recovered);
                    local_active_cases.setText(active);
                    local_death_toll.setText(deaths);
                    local_mortality_rate.setText(mortality_rate);
                    data_last_updated.setText("Last Updated: "+String.valueOf(time));
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    // gets the local country using the client IP
    public String getCountry() {
        Locale locale = Locale.getDefault();
        //return locale.getCountry().toLowerCase();
        return "canada";
    }
}
