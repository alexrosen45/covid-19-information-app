package com.covid19.covid_19_app.VaccineInformation;

public class VaccineDescription {
    private String description;

    public VaccineDescription() {}
    public VaccineDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setDescription(String description) {
        this.description = description;
    }
}
