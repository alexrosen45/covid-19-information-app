package com.covid19.covid_19_app.GlobalNews;

public class GlobalNewsUrlData {
    private String url;

    public GlobalNewsUrlData() {}
    public GlobalNewsUrlData(String source) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setUrl(String url) {
        this.url = url;
    }
}
