package com.covid19.covid_19_app.GlobalNews;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.covid19.covid_19_app.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class GlobalNewsAdapter extends RecyclerView.Adapter<GlobalNewsAdapter.ViewHolder> {

    private ArrayList<GlobalNewsData> globalNewsTitleData;
    private ArrayList<GlobalNewsDateData> globalNewsDateData;
    private ArrayList<GlobalNewsSourceData> globalNewsSourceData;
    private ArrayList<GlobalNewsImageData> globalNewsImageData;

    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick (int position);
    }

    public void setOnItemClickListener(OnItemClickListener clickListener) {
        listener = clickListener;
    }

    public GlobalNewsAdapter(
            ArrayList<GlobalNewsData> globalNewsTitleData,
            ArrayList<GlobalNewsDateData> globalNewsDateData,
            ArrayList<GlobalNewsSourceData> globalNewsSourceData,
            ArrayList<GlobalNewsImageData> globalNewsImageData) {

        this.globalNewsTitleData = globalNewsTitleData;
        this.globalNewsDateData = globalNewsDateData;
        this.globalNewsSourceData = globalNewsSourceData;
        this.globalNewsImageData = globalNewsImageData;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView title;
        private TextView date;
        private TextView source;
        private ImageView image;

        public ViewHolder(final View view) {
            super(view);
            title = view.findViewById(R.id.news_news_title);
            date = view.findViewById(R.id.news_news_date);
            source = view.findViewById(R.id.news_news_source);
            image = view.findViewById(R.id.news_news_image);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener!=null) {
                        int position = getAdapterPosition();
                        if (position!=RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }


    @NonNull
    @Override
    public GlobalNewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.items, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull GlobalNewsAdapter.ViewHolder holder, int position) {
        String news_title = globalNewsTitleData.get(position).getTitle();
        String news_date = globalNewsDateData.get(position).getDate();
        String news_source = globalNewsSourceData.get(position).getSource();
        String news_image = globalNewsImageData.get(position).getImage();

        holder.title.setText(news_title);
        holder.date.setText(news_date);
        holder.source.setText(news_source);
        Picasso.get().load(news_image).into(holder.image);
    }

    @Override
    public int getItemCount() {
        return globalNewsTitleData.size();
    }
}
