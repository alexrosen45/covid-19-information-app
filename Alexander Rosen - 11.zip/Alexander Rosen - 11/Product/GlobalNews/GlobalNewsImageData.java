package com.covid19.covid_19_app.GlobalNews;

public class GlobalNewsImageData {
    private String image;

    public GlobalNewsImageData() {}
    public GlobalNewsImageData(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setSource(String source) {
        this.image = image;
    }
}
