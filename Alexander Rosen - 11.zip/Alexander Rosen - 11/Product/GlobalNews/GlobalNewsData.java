package com.covid19.covid_19_app.GlobalNews;

public class GlobalNewsData {
    private String title;

    public GlobalNewsData() {}
    public GlobalNewsData(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setTitle(String title) {
        this.title = title;
    }
}

