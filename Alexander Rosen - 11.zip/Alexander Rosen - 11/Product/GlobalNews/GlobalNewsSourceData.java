package com.covid19.covid_19_app.GlobalNews;

public class GlobalNewsSourceData {
    private String source;

    public GlobalNewsSourceData() {}
    public GlobalNewsSourceData(String source) {
        this.source = source;
    }

    public String getSource() {
        return source;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setSource(String source) {
        this.source = source;
    }
}
