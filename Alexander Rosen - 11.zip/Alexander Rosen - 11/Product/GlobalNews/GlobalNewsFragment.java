package com.covid19.covid_19_app.GlobalNews;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.covid19.covid_19_app.GlobalNews.GlobalNewsAdapter;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsData;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsDateData;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsImageData;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsSourceData;
import com.covid19.covid_19_app.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class GlobalNewsFragment extends Fragment {

    String News_Url;
    View v;

    Button global_news_load;
    TextView global_news_load_text;

    private RecyclerView recyclerView;
    private GlobalNewsAdapter adapter;

    List<String> globalNewsData;
    private List<GlobalNewsData> globalNewsDataDisplay;
    private List<GlobalNewsDateData> globalNewsDateDataDisplay;
    private List<GlobalNewsSourceData> globalNewsSourceDataDisplay;
    private List<GlobalNewsImageData> globalNewsImageDataDisplay;
    private List<String> globalNewsUrlDataDisplay;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_global_news, container, false);

        recyclerView = v.findViewById(R.id.global_news_list);

        globalNewsData = new ArrayList<>();
        globalNewsDataDisplay = new ArrayList<>();
        globalNewsDateDataDisplay = new ArrayList<>();
        globalNewsSourceDataDisplay = new ArrayList<>();
        globalNewsImageDataDisplay = new ArrayList<>();
        globalNewsUrlDataDisplay = new ArrayList<String>();

        News_Url = "https://gnews.io/api/v3/search?q=covid&token=239e7bdf30ab37952d6b775a26fa6c7a";
        new com.covid19.covid_19_app.GlobalNews.GlobalNewsFragment.Asynchttptask().execute(News_Url);

        global_news_load = (Button) v.findViewById(R.id.global_news_load);
        global_news_load_text = (TextView) v.findViewById(R.id.global_news_load);

        global_news_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAdapter();
                global_news_load_text.setText("Reload Global News");

            }
        });
        return v;
    }




    private void setAdapter() {
        GlobalNewsAdapter adapter = new GlobalNewsAdapter(
                (ArrayList<GlobalNewsData>) globalNewsDataDisplay,
                (ArrayList<GlobalNewsDateData>) globalNewsDateDataDisplay,
                (ArrayList<GlobalNewsSourceData>) globalNewsSourceDataDisplay,
                (ArrayList<GlobalNewsImageData>) globalNewsImageDataDisplay);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new GlobalNewsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(globalNewsUrlDataDisplay.get(position)));
                startActivity(browserIntent);
            }
        });
    }



    public class Asynchttptask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String result = "";
            String response = "";
            URL url;
            HttpURLConnection urlConnection = null;

            // urls can be null so try and catch will stop the app from crashing
            try {
                url = new URL (urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                int responseCode = urlConnection.getResponseCode();

                // stops data from being parsed if it is html and not json
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    response = streamToString(urlConnection.getErrorStream());
                } else {
                    response = streamToString(urlConnection.getInputStream());
                }
                // if there is an error with connecting uncomment the comments below
                // if it still does not work try change "POST" to "GET"
                //urlConnection.connect();
                //urlConnection.setRequestMethod("POST");
                //response = streamToString(urlConnection.getInputStream());
                parseResult(response);
                return result;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    String streamToString(InputStream stream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
        String data;
        String result = "";

        // while there is data being streamed convert that data to a string
        while ((data = bufferedReader.readLine()) != null) {
            result+=data;
        }
        if (stream != null) {
            stream.close();
        }
        return result;
    }

    private void parseResult(String result) {
        JSONObject response = null;
        TextView textView = (TextView) v.findViewById(R.id.global_news_title);

        // result can be null so try and catch will stop the app from crashing
        try {
            response = new JSONObject(result);
            JSONArray articles = response.getJSONArray("articles");
            for (int i = 0; i<articles.length(); i++) {
                JSONObject article = articles.optJSONObject(i);
                JSONObject sources = article.optJSONObject("source");

                String title = article.optString("title");
                String date = article.optString("publishedAt");
                String source = sources.optString("name");
                String image = article.optString("image");
                String url = article.optString("url");

                globalNewsDataDisplay.add(new GlobalNewsData(title));
                globalNewsDateDataDisplay.add(new GlobalNewsDateData(date));
                globalNewsSourceDataDisplay.add(new GlobalNewsSourceData(source));
                globalNewsImageDataDisplay.add(new GlobalNewsImageData(image));
                globalNewsUrlDataDisplay.add(url);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}