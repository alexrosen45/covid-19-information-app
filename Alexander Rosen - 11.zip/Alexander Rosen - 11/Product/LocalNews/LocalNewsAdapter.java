package com.covid19.covid_19_app.LocalNews;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.covid19.covid_19_app.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class LocalNewsAdapter extends RecyclerView.Adapter<LocalNewsAdapter.ViewHolder> {

    private ArrayList<LocalNewsData> localNewsTitleData;
    private ArrayList<LocalNewsDateData> localNewsDateData;
    private ArrayList<LocalNewsSourceData> localNewsSourceData;
    private ArrayList<LocalNewsImageData> localNewsImageData;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick (int position);
    }
    public void setOnItemClickListener(OnItemClickListener clickListener) {
        listener = clickListener;
    }

    public LocalNewsAdapter(
            ArrayList<LocalNewsData> localNewsTitleData,
            ArrayList<LocalNewsDateData> localNewsDateData,
            ArrayList<LocalNewsSourceData> localNewsSourceData,
            ArrayList<LocalNewsImageData> localNewsImageData) {

        this.localNewsTitleData = localNewsTitleData;
        this.localNewsDateData = localNewsDateData;
        this.localNewsSourceData = localNewsSourceData;
        this.localNewsImageData = localNewsImageData;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView title;
        private TextView date;
        private TextView source;
        private ImageView image;

        public ViewHolder(final View view) {
            super(view);
            title = view.findViewById(R.id.news_news_title);
            date = view.findViewById(R.id.news_news_date);
            source = view.findViewById(R.id.news_news_source);
            image = view.findViewById(R.id.news_news_image);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener!=null) {
                        int position = getAdapterPosition();
                        if (position!=RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }


    @NonNull
    @Override
    public LocalNewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.items, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull LocalNewsAdapter.ViewHolder holder, int position) {
        String news_title = localNewsTitleData.get(position).getTitle();
        String news_date = localNewsDateData.get(position).getDate();
        String news_source = localNewsSourceData.get(position).getSource();
        String news_image = localNewsImageData.get(position).getImage();

        holder.title.setText(news_title);
        holder.date.setText(news_date);
        holder.source.setText(news_source);
        Picasso.get().load(news_image).into(holder.image);
    }

    @Override
    public int getItemCount() {
        return localNewsTitleData.size();
    }
}
