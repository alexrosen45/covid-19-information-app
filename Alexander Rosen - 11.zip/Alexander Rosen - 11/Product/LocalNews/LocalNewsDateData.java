package com.covid19.covid_19_app.LocalNews;

public class LocalNewsDateData {
    private String date;

    public LocalNewsDateData() {}
    public LocalNewsDateData(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setDate(String date) {
        this.date = date;
    }
}

