package com.covid19.covid_19_app.LocalNews;

public class LocalNewsImageData {
    private String image;

    public LocalNewsImageData() {}
    public LocalNewsImageData(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setSource(String source) {
        this.image = image;
    }
}
