package com.covid19.covid_19_app.LocalNews;

public class LocalNewsUrlData {
    private String url;

    public LocalNewsUrlData() {}
    public LocalNewsUrlData(String source) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setUrl(String url) {
        this.url = url;
    }
}
