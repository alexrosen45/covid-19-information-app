package com.covid19.covid_19_app.LocalNews;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.covid19.covid_19_app.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LocalNewsFragment extends Fragment {

    String News_Url;
    String Specific_Url;

    View v;

    Button local_news_load;
    TextView local_news_load_text;

    private RecyclerView recyclerView;

    List<String> localNewsData;
    private List<LocalNewsData> localNewsDataDisplay;
    private List<LocalNewsDateData> localNewsDateDataDisplay;
    private List<LocalNewsSourceData> localNewsSourceDataDisplay;
    private List<LocalNewsImageData> localNewsImageDataDisplay;
    private List<String> localNewsUrlDataDisplay;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_local_news, container, false);

        recyclerView = v.findViewById(R.id.local_news_list);

        localNewsData = new ArrayList<>();
        localNewsDataDisplay = new ArrayList<>();
        localNewsDateDataDisplay = new ArrayList<>();
        localNewsSourceDataDisplay = new ArrayList<>();
        localNewsImageDataDisplay = new ArrayList<>();
        localNewsUrlDataDisplay = new ArrayList<String>();

        News_Url = "https://gnews.io/api/v3/search?q=covid&token=239e7bdf30ab37952d6b775a26fa6c7a";
        Specific_Url = addCountry(News_Url);
        new LocalNewsFragment.Asynchttptask().execute(Specific_Url);

        local_news_load = (Button) v.findViewById(R.id.local_news_load);
        local_news_load_text = (TextView) v.findViewById(R.id.local_news_load);

        local_news_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAdapter();
                local_news_load_text.setText("Reload Local News");
            }
        });
        return v;
    }




    private void setAdapter() {
        LocalNewsAdapter adapter = new LocalNewsAdapter(
                (ArrayList<LocalNewsData>) localNewsDataDisplay,
                (ArrayList<LocalNewsDateData>) localNewsDateDataDisplay,
                (ArrayList<LocalNewsSourceData>) localNewsSourceDataDisplay,
                (ArrayList<LocalNewsImageData>) localNewsImageDataDisplay);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new LocalNewsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(localNewsUrlDataDisplay.get(position)));
                startActivity(browserIntent);
            }
        });
    }



    public class Asynchttptask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String result = "";
            String response = "";
            URL url;
            HttpURLConnection urlConnection = null;

            // urls can be null so try and catch will stop the app from crashing
            try {
                url = new URL (urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                int responseCode = urlConnection.getResponseCode();

                // stops data from being parsed if it is html and not json
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    response = streamToString(urlConnection.getErrorStream());
                } else {
                    response = streamToString(urlConnection.getInputStream());
                }
                // if there is an error with connecting uncomment the comments below
                // if it still does not work try change "POST" to "GET"
                //urlConnection.connect();
                //urlConnection.setRequestMethod("POST");
                //response = streamToString(urlConnection.getInputStream());
                parseResult(response);
                return result;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    String streamToString(InputStream stream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
        String data;
        String result = "";

        // while there is data being streamed convert that data to a string
        while ((data = bufferedReader.readLine()) != null) {
            result+=data;
        }
        if (stream != null) {
            stream.close();
        }
        return result;
    }

    private void parseResult(String result) {
        JSONObject response = null;
        TextView textView = (TextView) v.findViewById(R.id.local_news_title);

        // result can be null so try and catch will stop the app from crashing
        try {
            response = new JSONObject(result);
            JSONArray articles = response.getJSONArray("articles");
            for (int i = 0; i<articles.length(); i++) {
                JSONObject article = articles.optJSONObject(i);
                JSONObject sources = article.optJSONObject("source");

                String title = article.optString("title");
                String date = article.optString("publishedAt");
                String source = sources.optString("name");
                String image = article.optString("image");
                String url = article.optString("url");

                localNewsDataDisplay.add(new LocalNewsData(title));
                localNewsDateDataDisplay.add(new LocalNewsDateData(date));
                localNewsSourceDataDisplay.add(new LocalNewsSourceData(source));
                localNewsImageDataDisplay.add(new LocalNewsImageData(image));
                localNewsUrlDataDisplay.add(url);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    // gets the local country using the client IP
    public String addCountry(String News_Url) {
        Locale locale = Locale.getDefault();
        String country = locale.getCountry();
        if (country.toLowerCase().equals("ca")) {
            country = "canada";
        }
        country = "canada";

        return "https://gnews.io/api/v3/search?q=covid%20"+country.toLowerCase()+"&token=239e7bdf30ab37952d6b775a26fa6c7a";
    }
}
