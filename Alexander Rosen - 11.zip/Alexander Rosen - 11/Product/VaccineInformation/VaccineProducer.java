package com.covid19.covid_19_app.VaccineInformation;

public class VaccineProducer {
    private String producer;

    public VaccineProducer() {}
    public VaccineProducer(String producer) {
        this.producer = producer;
    }

    public String getProducer() {
        return producer;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setProducer(String producer) {
        this.producer = producer;
    }
}
