package com.covid19.covid_19_app.VaccineInformation;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.covid19.covid_19_app.GlobalNews.GlobalNewsAdapter;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsData;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsDateData;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsImageData;
import com.covid19.covid_19_app.GlobalNews.GlobalNewsSourceData;
import com.covid19.covid_19_app.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class VaccineInformationFragment extends Fragment {

    View v;

    Button load;

    private RecyclerView recyclerView;
    private VaccineInformationAdapter adapter;

    List<VaccineTitle> vaccineTitleDisplay;
    List<VaccineProducer> vaccineProducerDisplay;
    List<VaccineDescription> vaccineDescriptionDisplay;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_vaccine_information, container, false);

        recyclerView = v.findViewById(R.id.vaccines_list);

        load = (Button) v.findViewById(R.id.vaccine_information_button);

        vaccineTitleDisplay = new ArrayList<>();
        vaccineProducerDisplay = new ArrayList<>();
        vaccineDescriptionDisplay = new ArrayList<>();

        // unblocks http requests
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        parseResult();
        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAdapter();
                load.setText("Reload Vaccine Tracker");

            }
        });

        return v;
    }

    private void setAdapter() {
        VaccineInformationAdapter adapter = new VaccineInformationAdapter(
                (ArrayList<VaccineTitle>) vaccineTitleDisplay,
                (ArrayList<VaccineProducer>) vaccineProducerDisplay,
                (ArrayList<VaccineDescription>) vaccineDescriptionDisplay);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }

    // getting JSON data from RAPID API with OkHttp
    private void parseResult() {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("https://vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com/api/vaccines/get-fda-approved-vaccines")
                .get()
                .addHeader("x-rapidapi-key", "0476b37b7dmshb9aee0a18e6ea9cp15bfa4jsnf9b09528d1f9")
                .addHeader("x-rapidapi-host", "vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com")
                .build();

        Log.i("request", String.valueOf(request));

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                Log.i("message", "error");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    // result can be null so try and catch will stop the app from crashing
                    try {
                        JSONArray vaccines = new JSONArray(response.body().string());

                        for (int i = 0; i<vaccines.length(); i++) {
                            JSONObject vaccine = vaccines.optJSONObject(i);

                            String titles = vaccine.optString("trimedCategory");
                            String producers = vaccine.optString("trimedName");
                            String descriptions = vaccine.optString("description");

                            List<String> title = Arrays.asList(titles.split(","));
                            List<String> producer = Arrays.asList(producers.split(","));
                            List<String> description = Arrays.asList(descriptions.split(","));

                            String producer_final = "Vaccine Developer/Researcher: "+producer.get(0);
                            String description_final = "Vaccine Description: "+description.get(0);

                            vaccineTitleDisplay.add(new VaccineTitle(title.get(0)));
                            vaccineProducerDisplay.add(new VaccineProducer(producer_final));
                            vaccineDescriptionDisplay.add(new VaccineDescription(description_final));
                        }
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }
}
