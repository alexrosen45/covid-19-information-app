package com.covid19.covid_19_app.VaccineInformation;

public class VaccineTitle {
    private String title;

    public VaccineTitle() {}
    public VaccineTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    // setter creates the data manually and stores it to become an object
    // getter returns the data already assigned to the object
    public void setTitle(String title) {
        this.title = title;
    }
}
