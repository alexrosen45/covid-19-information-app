package com.covid19.covid_19_app.VaccineInformation;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.covid19.covid_19_app.VaccineInformation.VaccineTitle;
import com.covid19.covid_19_app.VaccineInformation.VaccineProducer;
import com.covid19.covid_19_app.VaccineInformation.VaccineDescription;
import com.covid19.covid_19_app.R;

import java.util.ArrayList;

public class VaccineInformationAdapter extends RecyclerView.Adapter<VaccineInformationAdapter.ViewHolder> {

    private ArrayList<VaccineTitle> vaccineTitle;
    private ArrayList<VaccineProducer> vaccineProducer;
    private ArrayList<VaccineDescription> vaccineDescription;

    public VaccineInformationAdapter(
            ArrayList<VaccineTitle> vaccineTitle,
            ArrayList<VaccineProducer> vaccineProducer,
            ArrayList<VaccineDescription> vaccineDescription) {

        this.vaccineTitle = vaccineTitle;
        this.vaccineProducer = vaccineProducer;
        this.vaccineDescription = vaccineDescription;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView title;
        private TextView producer;
        private TextView description;

        public ViewHolder(final View view) {
            super(view);
            title = view.findViewById(R.id.vaccine_title);
            producer = view.findViewById(R.id.vaccine_producer);
            description = view.findViewById(R.id.vaccine_description);
        }
    }


    @NonNull
    @Override
    public com.covid19.covid_19_app.VaccineInformation.VaccineInformationAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.items2, parent, false);
        return new com.covid19.covid_19_app.VaccineInformation.VaccineInformationAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull com.covid19.covid_19_app.VaccineInformation.VaccineInformationAdapter.ViewHolder holder, int position) {
        String vaccine_title = vaccineTitle.get(position).getTitle();
        String vaccine_producer = vaccineProducer.get(position).getProducer();
        String vaccine_description = vaccineDescription.get(position).getDescription();

        holder.title.setText(vaccine_title);
        holder.producer.setText(vaccine_producer);
        holder.description.setText(vaccine_description);
    }

    @Override
    public int getItemCount() {
        return vaccineTitle.size();
    }
}